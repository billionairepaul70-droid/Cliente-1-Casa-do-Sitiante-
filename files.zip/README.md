# Casa do Sitiante — Site Institucional

Site estático (HTML + CSS + JS puro, sem frameworks) pronto para editar no VS Code e publicar online.

## Estrutura

```
casa-do-sitiante/
├── index.html        → todo o conteúdo e estrutura das seções
├── css/style.css      → identidade visual (vermelho/prata/branco), responsivo
├── js/script.js        → menu mobile e efeito de rolagem no header
└── assets/              → pasta vazia para você colocar logo, fotos e imagens reais
```

## Como rodar localmente no VS Code

1. Abra a pasta `casa-do-sitiante` no VS Code (`File > Open Folder`).
2. Instale a extensão **Live Server** (Ritwick Dey) pelo menu de extensões.
3. Clique com o botão direito em `index.html` → **Open with Live Server**.
4. O site abrirá em `http://127.0.0.1:5500` e atualiza sozinho a cada alteração salva.

Alternativa sem extensão (usando Python, se instalado):
```bash
cd casa-do-sitiante
python3 -m http.server 5500
```
Depois acesse `http://localhost:5500` no navegador.

## O que ainda falta preencher

- **Imagens reais**: logo em alta resolução, fotos da fachada, produtos e da equipe (coloque em `assets/` e referencie no `index.html`).
- **Número do WhatsApp**: já usei `(11) 4039-2138` no formato `https://wa.me/551140392138`. Se o WhatsApp comercial for outro número, atualize todos os links `wa.me` no `index.html` e no botão flutuante.
- **Horário de funcionamento**: só o horário de sexta-feira (8h–18h) estava confirmado no briefing. Os demais dias estão como "a confirmar" na seção Localização — edite a lista `.horario-list` no `index.html`.
- **Fonte "impact"/condensada da fachada**: usei `Archivo Black` (Google Fonts) como aproximação gratuita. Se vocês tiverem a fonte oficial da marca, troque o `<link>` do Google Fonts e a variável `--font-display` no `style.css`.

## Publicar online (grátis, sem servidor próprio)

**Opção mais simples — Netlify Drop:**
1. Acesse [app.netlify.com/drop](https://app.netlify.com/drop).
2. Arraste a pasta `casa-do-sitiante` inteira para a página.
3. Pronto — você recebe uma URL pública em segundos. Depois é possível conectar o domínio `casadositiante.com.br` nas configurações do site.

**Opção com controle de versão — GitHub Pages:**
1. Crie um repositório no GitHub e envie os arquivos desta pasta.
2. Em *Settings → Pages*, selecione a branch `main` e a pasta raiz (`/`).
3. O GitHub gera uma URL pública; depois você aponta o domínio próprio (`casadositiante.com.br`) nas configurações de DNS.

## Observações técnicas

- O site é **mobile-first** e totalmente responsivo (testado nos breakpoints 900px e 760px).
- O botão flutuante do WhatsApp aparece em todas as seções.
- O mapa da seção "Localização" usa um `iframe` do Google Maps sem necessidade de chave de API.
- Não há dependências externas além das fontes do Google Fonts — nenhum `npm install` é necessário.
